import { useToast } from "vue-toastification";

const toast = useToast();

export default toast;
